class Note:
    def __init__(self, nota):
        self.nota = nota

    def play(self):
        print(self.nota)